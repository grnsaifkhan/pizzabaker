create function get_avail_ingredients_with_morethan_zerostock()
    returns TABLE(pk integer, names character varying, regional_provenances character varying, prices numeric, from_bakers boolean, is_shows boolean)
    language plpgsql
as
$$
begin
    return query select id ,name ,regional_provenance ,price ,from_baker,  is_show from ingredients where is_show = true and stock_amount > 0;
end
$$;

alter function get_avail_ingredients_with_morethan_zerostock() owner to pizzabaker_rw;

