create function insert_suppliers(name character varying, is_active boolean) returns integer
    language plpgsql
as
$$
begin
    insert into suppliers(name, is_active) values (name, is_active) ;
    return (select id from suppliers order by id desc limit 1);
end
$$;

alter function insert_suppliers(varchar, boolean) owner to pizzabaker_rw;

