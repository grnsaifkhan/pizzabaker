create function generate_order(customer_id integer, compostion_id integer, created_on timestamp without time zone) returns character varying
    language plpgsql
as
$$
DECLARE
    r record;
    result bool;
    current_stock int;
begin
    result := false;
    FOR r in
        select * from composition_configs t where t.pizza_composition_id = compostion_id
        LOOP
            select ing.stock_amount into current_stock from ingredients ing where ing.id = r.ingredients_id;
            if r.quantity > current_stock then
                return 'Stock out for this order';
            end if;
        end loop;
    insert into orders(customer_id, composition_id, created_on) values (customer_id, compostion_id, created_on);
    perform change_stock(compostion_id);
    return 'Order Successfully created';

end
$$;

alter function generate_order(integer, integer, timestamp) owner to pizzabaker_rw;

