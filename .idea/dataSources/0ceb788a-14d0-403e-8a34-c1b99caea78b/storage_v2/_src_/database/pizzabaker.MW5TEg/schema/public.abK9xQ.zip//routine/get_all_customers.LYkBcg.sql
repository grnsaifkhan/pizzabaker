create function get_all_customers()
    returns TABLE(pk integer, names character varying)
    language plpgsql
as
$$
begin
    return query select id ,name  from customers ;

end
$$;

alter function get_all_customers() owner to pizzabaker_rw;

