create function update_ingredients(id_info integer, name_info character varying, reg_prov character varying, prc numeric, from_bk boolean, is_shw boolean)
    returns TABLE(names character varying, regional_provenances character varying, prices numeric, from_bakers boolean, is_shows boolean)
    language plpgsql
as
$$
begin
    update ingredients set name = name_info, regional_provenance = reg_prov, price = prc, from_baker = from_bk, is_show = is_shw where id = id_info ;
    return query select name, regional_provenance, price, from_baker, is_show from ingredients where id = id_info;
end
$$;

alter function update_ingredients(integer, varchar, varchar, numeric, boolean, boolean) owner to pizzabaker_rw;

