create function get_all_avail_ingred_for_supplier()
    returns TABLE(pk integer, names character varying, regional_provenances character varying, prices numeric, from_bakers boolean, is_shows boolean)
    language plpgsql
as
$$
begin
    return query select id ,name ,regional_provenance ,price ,from_baker,  is_show from ingredients where is_show = true and from_baker = false;
end
$$;

alter function get_all_avail_ingred_for_supplier() owner to pizzabaker_rw;

