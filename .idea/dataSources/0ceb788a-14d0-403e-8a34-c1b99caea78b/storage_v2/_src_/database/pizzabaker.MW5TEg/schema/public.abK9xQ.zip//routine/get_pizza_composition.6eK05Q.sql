create function get_pizza_composition()
    returns TABLE(composition_id integer, composition_size character varying)
    language plpgsql
as
$$
begin
    return query select id ,pizza_size from pizza_compositions;
end
$$;

alter function get_pizza_composition() owner to pizzabaker_rw;

