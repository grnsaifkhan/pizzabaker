create function update_ingredients(id_info integer, is_shw boolean)
    returns TABLE(is_shows boolean)
    language plpgsql
as
$$
begin
    update ingredients set is_show = is_shw where id = id_info ;
    return query select is_show from ingredients where id = id_info;
end
$$;

alter function update_ingredients(integer, boolean) owner to pizzabaker_rw;

