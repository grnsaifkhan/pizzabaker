create function restock_ingredients(pk integer) returns character varying
    language plpgsql
as
$$
DECLARE
    r record;
    ing_ass record;
    is_from_baker bool;
    current_stock int;
    curr_active bool;
begin
    select ingd.from_baker, ingd.stock_amount into is_from_baker, current_stock from ingredients as ingd where id=pk;
    if is_from_baker then
        update ingredients set stock_amount = current_stock +10 where id=pk;
        return 'SUCCESSFULLY RESTOCK THE INGREDIENTS';
    else
        for r in select * from ingredients_assortment where ingredients_id = pk
            loop
                select sup.is_active into curr_active from suppliers sup where sup.id = r.supplier_id;
                if curr_active then
                    update ingredients set stock_amount = current_stock +10 where id=pk;
                    return 'SUCCESSFULLY RESTOCK THE INGREDIENTS';
                end if;
            end loop;
    end if;
    return 'SUPPLIER NOT AVAILABLE TO RESTOCK THE INGREDIENTS';
end
$$;

alter function restock_ingredients(integer) owner to pizzabaker_rw;

