create function update_supplier(id_info integer, is_actv boolean)
    returns TABLE(actv boolean)
    language plpgsql
as
$$
begin
    update suppliers set  is_active = is_actv where id = id_info ;
    return query select is_active from suppliers where id = id_info;
end
$$;

alter function update_supplier(integer, boolean) owner to pizzabaker_rw;

