create function delete_pizza_compos_config_for_ingred(ingredientid integer) returns void
    language plpgsql
as
$$
begin
    DELETE FROM composition_configs where ingredients_id= ingredientId;
end
$$;

alter function delete_pizza_compos_config_for_ingred(integer) owner to pizzabaker_rw;

