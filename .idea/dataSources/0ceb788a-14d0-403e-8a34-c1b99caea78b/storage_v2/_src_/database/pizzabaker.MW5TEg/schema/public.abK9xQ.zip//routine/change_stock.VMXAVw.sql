create function change_stock(composition_id integer) returns character varying
    language plpgsql
as
$$
declare
    data_comp record;
    current_stock int;
begin

    for data_comp in
        select * from composition_configs com where com.pizza_composition_id = composition_id
        loop
            select ing.stock_amount into current_stock from ingredients ing where ing.id = data_comp.ingredients_id;
            update ingredients ing set stock_amount = (current_stock-data_comp.quantity) where ing.id=data_comp.ingredients_id;
        end loop;
    return 'success';
end
$$;

alter function change_stock(integer) owner to pizzabaker_rw;

