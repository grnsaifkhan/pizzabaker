create function get_all_suppliers(key_search character varying)
    returns TABLE(pk integer, names character varying, is_actives boolean)
    language plpgsql
as
$$
begin
    if key_search = 'ALL' then
        return query select id ,name ,is_active from suppliers;
    else
        return query select id ,name ,is_active from suppliers where is_active = true;
    end if;

end
$$;

alter function get_all_suppliers(varchar) owner to pizzabaker_rw;

