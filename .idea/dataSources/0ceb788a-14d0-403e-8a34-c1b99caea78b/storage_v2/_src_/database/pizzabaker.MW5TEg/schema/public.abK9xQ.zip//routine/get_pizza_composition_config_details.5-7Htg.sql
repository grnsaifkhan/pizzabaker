create function get_pizza_composition_config_details(comp_id integer)
    returns TABLE(compos_config_id integer, pizzacompositionid integer, ingredientsid integer, pizza_composition_quantity integer, composition_total_price numeric, ingredients_name character varying, reg_provenance character varying)
    language plpgsql
as
$$
begin
    return query select comp.id,comp.pizza_composition_id, comp.ingredients_id,comp.quantity,comp.total_price, ing.name, ing.regional_provenance from composition_configs as comp inner join (select * from ingredients where is_show=true) as ing ON ing.id = comp.ingredients_id and comp.pizza_composition_id = comp_id ;
end
$$;

alter function get_pizza_composition_config_details(integer) owner to pizzabaker_rw;

