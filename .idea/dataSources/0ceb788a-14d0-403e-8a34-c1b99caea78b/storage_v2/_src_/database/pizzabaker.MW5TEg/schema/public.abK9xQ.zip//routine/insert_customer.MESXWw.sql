create function insert_customer(name character varying) returns integer
    language plpgsql
as
$$
begin
    insert into customers(name) values (name) ;
    return (select id from customers order by id desc limit 1);
end
$$;

alter function insert_customer(varchar) owner to pizzabaker_rw;

