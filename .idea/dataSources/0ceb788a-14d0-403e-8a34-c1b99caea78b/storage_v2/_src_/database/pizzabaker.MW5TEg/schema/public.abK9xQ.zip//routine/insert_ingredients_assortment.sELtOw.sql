create function insert_ingredients_assortment(ingredients_id integer, supplier_id integer) returns integer
    language plpgsql
as
$$
begin
    insert into ingredients_assortment(ingredients_id, supplier_id) values (ingredients_id, supplier_id) ;
    return (select id from ingredients_assortment order by id desc limit 1);
end
$$;

alter function insert_ingredients_assortment(integer, integer) owner to pizzabaker_rw;

