create function insert_pizza_compositions(pizza_size character varying) returns integer
    language plpgsql
as
$$
begin
    insert into pizza_compositions(pizza_size) values (pizza_size) ;
    return (select id from pizza_compositions order by id desc limit 1);
end
$$;

alter function insert_pizza_compositions(varchar) owner to pizzabaker_rw;

