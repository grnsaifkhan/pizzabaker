create function get_all_ingredients()
    returns TABLE(pk integer, names character varying, regional_provenances character varying, prices numeric, from_bakers boolean, stock_amounts integer, is_shows boolean)
    language plpgsql
as
$$
begin
    return query select id ,name ,regional_provenance ,price ,from_baker,  stock_amount ,is_show from ingredients;
end
$$;

alter function get_all_ingredients() owner to pizzabaker_rw;

