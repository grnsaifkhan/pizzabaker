create function delete_supplier(id_info integer) returns void
    language plpgsql
as
$$
begin
    delete from suppliers where id = id_info ;
end
$$;

alter function delete_supplier(integer) owner to pizzabaker_rw;

