create function insert_pizza_compositions_config(pizza_composition_id integer, ingredients_id integer, quantity integer, total_price numeric) returns integer
    language plpgsql
as
$$
begin
    insert into composition_configs(pizza_composition_id, ingredients_id,quantity,total_price) values (pizza_composition_id, ingredients_id,quantity,total_price) ;
    return (select id from composition_configs order by id desc limit 1);
end
$$;

alter function insert_pizza_compositions_config(integer, integer, integer, numeric) owner to pizzabaker_rw;

