create function update_supplier(id_info integer, sup_name character varying)
    returns TABLE(suppl_name character varying)
    language plpgsql
as
$$
begin
    update suppliers set  name = sup_name where id = id_info ;
    return query select name from suppliers where id = id_info;
end
$$;

alter function update_supplier(integer, varchar) owner to pizzabaker_rw;

