create function get_order()
    returns TABLE(order_id integer, customerid integer, compositionid integer, createdon timestamp without time zone)
    language plpgsql
as
$$
begin
    return query select id,customer_id,composition_id,created_on from orders order by created_on desc;
end
$$;

alter function get_order() owner to pizzabaker_rw;

