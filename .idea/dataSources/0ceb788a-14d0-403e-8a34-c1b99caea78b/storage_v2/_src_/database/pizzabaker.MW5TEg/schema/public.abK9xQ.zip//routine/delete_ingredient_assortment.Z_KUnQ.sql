create function delete_ingredient_assortment(ingred_id integer, supp_id integer) returns character varying
    language plpgsql
as
$$
declare
    data_comp record;
    current_stock int;
begin
    delete from ingredients_assortment ing_assort where ing_assort.ingredients_id=ingred_id or ing_assort.supplier_id= supp_id;
    return 'DELETED SUCCESSFULLY';
end
$$;

alter function delete_ingredient_assortment(integer, integer) owner to pizzabaker_rw;

