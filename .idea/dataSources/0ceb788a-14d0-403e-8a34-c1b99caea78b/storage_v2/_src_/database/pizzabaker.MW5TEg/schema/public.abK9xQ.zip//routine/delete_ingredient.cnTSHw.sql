create function delete_ingredient(id_info integer) returns void
    language plpgsql
as
$$
begin
    delete from ingredients where id = id_info ;
end
$$;

alter function delete_ingredient(integer) owner to pizzabaker_rw;

