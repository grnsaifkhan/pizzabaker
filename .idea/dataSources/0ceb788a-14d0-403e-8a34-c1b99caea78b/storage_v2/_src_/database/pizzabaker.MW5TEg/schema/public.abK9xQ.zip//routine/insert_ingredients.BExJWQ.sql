create function insert_ingredients(name character varying, regional_provenance character varying, price numeric, from_baker boolean, stock_amount integer, is_show boolean) returns integer
    language plpgsql
as
$$
begin
    insert into ingredients(name, regional_provenance, price, from_baker,  stock_amount, is_show) values (name, regional_provenance, price, from_baker,  stock_amount, is_show) ;
    return (select id from ingredients order by id desc limit 1);
end
$$;

alter function insert_ingredients(varchar, varchar, numeric, boolean, integer, boolean) owner to pizzabaker_rw;

