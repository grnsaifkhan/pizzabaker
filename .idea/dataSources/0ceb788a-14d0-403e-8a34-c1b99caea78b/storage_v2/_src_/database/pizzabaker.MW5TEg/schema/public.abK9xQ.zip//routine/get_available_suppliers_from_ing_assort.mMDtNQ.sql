create function get_available_suppliers_from_ing_assort(ing_id integer)
    returns TABLE(ids integer, sup_name character varying)
    language plpgsql
as
$$
DECLARE
    r record;
begin
    return query select sup.id,sup.name from suppliers as sup inner join (select * from ingredients_assortment as ing_assort where ing_assort.ingredients_id = ing_id ) as item on item.supplier_id = sup.id;
end
$$;

alter function get_available_suppliers_from_ing_assort(integer) owner to pizzabaker_rw;

